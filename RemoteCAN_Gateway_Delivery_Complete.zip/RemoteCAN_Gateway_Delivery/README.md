# RemoteCAN Gateway Rev A

KiCad 9 project for a 12 V, 433 MHz UART receiver to Classical CAN gateway.

## Open

Open `RemoteCAN_Gateway.kicad_pro` in KiCad 9. The editable board is `RemoteCAN_Gateway.kicad_pcb`. The schematic is supplied in KiCad legacy `.sch` format and KiCad 9 will offer to convert it on first save.

## Important engineering status

This is an editable Rev-A placement/concept project, not fabrication-ready and not an automotive-qualified production release. The included DRC report intentionally records remaining clearance, short, and unrouted-net findings; do not order this revision. Before final routing, select the exact 433 MHz UART receiver and verify its pin order, mechanical envelope, protocol, logic voltage, and repeat timing. Replace the U1 functional module/placeholder with the complete power-stage values from the selected regulator datasheet, then resolve every ERC/DRC item.

The PCB includes a ground pour; refill zones (`B`) after editing. Split termination parts are DNP unless the gateway is at a CAN bus end. Gerbers are deliberately not supplied because Rev A has not passed DRC.
