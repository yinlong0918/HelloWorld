# Electrical connection authority

The generated overview is for viewing. This table is the connection authority for the next schematic/layout revision.

## MCU

- STM32F103C8T6 pin 31 / PA10: `RF_RX_3V3`
- pin 32 / PA11: `CAN_RX`
- pin 33 / PA12: `CAN_TX`
- pin 34 / PA13: `SWDIO`
- pin 37 / PA14: `SWCLK`
- pin 7: `NRST`, 10 kΩ pull-up to 3.3 V
- pin 44: `BOOT0`, 100 kΩ pull-down
- pins 8, 23, 35, 47: GND
- pins 9, 24, 36, 48 and VBAT: 3.3 V

## CAN transceiver

- TCAN1042HGV-Q1 pin 1 TXD: MCU `CAN_TX`
- pin 2: GND
- pin 3 VCC: 5 V
- pin 4 RXD: MCU `CAN_RX`
- pin 5 VIO: 3.3 V
- pin 6: `CANL_PHY`
- pin 7: `CANH_PHY`
- pin 8 STB: MCU `CAN_STB`, with 10 kΩ pull-down

## RF receiver socket

- J2.1: 5 V
- J2.2: GND
- J2.3: module UART TX
- J2.4: reserved
- Populate the 10 kΩ/20 kΩ divider for a 5 V UART output. Bypass it only after verifying a 3.3 V output.

## CAN connector

- J3.1: CAN_H
- J3.2: CAN_L
- J3.3: signal ground
- J3.4: shield/chassis
- Split termination is 60.4 Ω + 60.4 Ω with a 4.7 nF midpoint capacitor, DNP unless at a physical bus end.
